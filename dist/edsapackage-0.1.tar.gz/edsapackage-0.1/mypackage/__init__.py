from . import myFunction
